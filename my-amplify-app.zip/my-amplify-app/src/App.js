import React from 'react';

function App() {
  return (
    <div>
      <h1>Hello from {process.env.REACT_APP_ENV} environment!</h1>
    </div>
  );
}

export default App;
